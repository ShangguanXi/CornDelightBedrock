const cookingPotRecipes = [
    {
        "identifer": "corn_delight:boiled_corn",
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:corn" }
        ],
        "result": {
            "item": "corn_delight:boiled_corn"
        }
    },
    {
        "identifer": "corn_delight:caramel_popcorn",
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:corn_seeds" },
            { "item": "minecraft:sugar" }
        ],
        "result": {
            "item": "corn_delight:caramel_popcorn"
        }
    },
    {
        "identifer": "corn_delight:classic_corn_dog",
        "container": {
            "item": "minecraft:stick"
        },
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:cornbread_batter" },
            [
                { "item": "minecraft:cooked_porkchop" },
                { "item": "minecraft:cooked_beef" },
                { "item": "minecraft:cooked_chicken" },
                { "item": "minecraft:cooked_mutton" },
                { "item": "farmersdelight:cooked_bacon" },
                { "item": "farmersdelight:cooked_chicken_cuts" },
                { "item": "farmersdelight:cooked_mutton_chops" },
                { "item": "farmersdelight:beef_patty" }
            ],
            { "item": "farmersdelight:tomato_sauce" }
        ],
        "result": {
            "item": "corn_delight:classic_corn_dog"
        }
    },
    {
        "identifer": "corn_delight:corn_dog",
        "container": { "item": "minecraft:stick" },
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:cornbread_batter" },
            { "tag": "minecraft:is_cooked" }
        ],
        "result": {
            "item": "corn_delight:corn_dog"
        }
    },
    {
        "identifer": "corn_delight:corn_soup",
        "tags": ["cooking_pot"],
        "container": {
            "item": "minecraft:bowl"
        },
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:corn" },
            { "tag": "farmersdelight:is_cabbage" },
            [
                { "tag": "farmersdelight:is_raw_porkchop" },
                { "tag": "farmersdelight:is_raw_chicken" },
                { "tag": "farmersdelight:is_raw_beef" },
                { "item": "minecraft:porkchop" },
                { "item": "minecraft:beef" },
                { "item": "minecraft:chicken" },
                { "item": "minecraft:brown_mushroom" }
            ],
            { "item": "farmersdelight:milk_bottle" }
        ],
        "result": {
            "item": "corn_delight:corn_soup"
        }
    },
    {
        "identifer": "corn_delight:cornbread_stuffing",
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:cornbread" },
            [
                { "item": "minecraft:carrot" },
                { "item": "minecraft:potato" },
                { "item": "minecraft:beetroot" },
                { "tag": "farmersdelight:is_onion" },
                { "tag": "farmersdelight:is_cabbage" },
                { "tag": "farmersdelight:is_tomato" }
            ],
            { "item": "minecraft:baked_potato" },
            { "item": "minecraft:sweet_berries" }
        ],
        "result": {
            "item": "corn_delight:cornbread_stuffing"
        }
    },
    {
        "identifer": "corn_delight:creamed_corn",
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:corn" },
            { "item": "corn_delight:corn" },
            { "item": "farmersdelight:milk_bottle" }
        ],
        "result": {
            "item": "corn_delight:creamed_corn"
        }
    },
    {
        "identifer": "corn_delight:creamy_corn_drink",
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:corn" },
            { "item": "minecraft:sugar" },
            { "item": "farmersdelight:milk_bottle" }
        ],
        "result": {
            "item": "corn_delight:creamy_corn_drink"
        }
    },
    {
        "identifer": "corn_delight:nachos_block_item",
        "tags": ["cooking_pot"],
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:tortilla_chip" },
            { "item": "corn_delight:tortilla_chip" },
            { "tag": "minecraft:is_cooked" },
            { "item": "farmersdelight:milk_bottle" },
            { "item": "farmersdelight:tomato_sauce" }
        ],
        "result": {
            "item": "corn_delight:nachos_block_item"
        }
    },
    {
        "identifer": "farmersdelight:stuffed_pumpkin_block_item",
        "tags": ["cooking_pot"],
        "container": {
            "item": "minecraft:pumpkin"
        },
        "priority": 0,
        "time": 200,
        "ingredients": [
            { "item": "corn_delight:cornbread" },
            [
                { "item": "minecraft:carrot" },
                { "item": "minecraft:potato" },
                { "item": "minecraft:beetroot" },
                { "tag": "farmersdelight:is_onion" },
                { "tag": "farmersdelight:is_cabbage" },
                { "tag": "farmersdelight:is_tomato" }
            ],
            { "item": "farmersdelight:tomato_sauce" },
            { "item": "farmersdelight:brown_mushroom_colony_item" },
            { "item": "minecraft:sweet_berries" }
        ],
        "result": {
            "item": "farmersdelight:stuffed_pumpkin_block_item"
        }
    }
];

export { cookingPotRecipes }